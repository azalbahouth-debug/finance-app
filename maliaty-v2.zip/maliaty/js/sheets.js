/* ═══════════════════════════════
   MALIATY — Sheets Integration
═══════════════════════════════ */

const Sheets = {
  BASE: 'https://sheets.googleapis.com/v4/spreadsheets',
  retryCount: 0,
  MAX_RETRY: 3,

  get sid() { return State.config.sheetId; },
  get key() { return State.config.apiKey; },
  get connected() { return !!(this.sid && this.key); },

  // ── FETCH with retry ──────────────────────────────────
  async fetch(url, opts = {}, attempt = 0) {
    try {
      const res = await fetch(url, { ...opts, signal: AbortSignal.timeout(10000) });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error?.message || `HTTP ${res.status}`);
      }
      return await res.json();
    } catch (e) {
      if (attempt < this.MAX_RETRY && e.name !== 'AbortError') {
        await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
        return this.fetch(url, opts, attempt + 1);
      }
      throw e;
    }
  },

  // ── BATCH GET key ranges ──────────────────────────────
  async batchGet(ranges) {
    const q = ranges.map(r => 'ranges=' + encodeURIComponent(r)).join('&');
    const url = `${this.BASE}/${this.sid}/values:batchGet?${q}&key=${this.key}`;
    return this.fetch(url);
  },

  // ── APPEND row to ENTRY LOG ───────────────────────────
  async appendRow(row) {
    const url = `${this.BASE}/${this.sid}/values/${encodeURIComponent("'ENTRY LOG'!B:F")}:append?valueInputOption=USER_ENTERED&key=${this.key}`;
    return this.fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ values: [row] }),
    });
  },

  // ── SYNC FULL DATA ────────────────────────────────────
  async sync() {
    if (!this.connected) return { ok: false, demo: true };
    State.syncStatus = 'syncing';
    UI.setSyncState('syncing');

    try {
      const RANGES = [
        'SETTINGS!C9',   // salary
        'SETTINGS!C13',  // emergency fund
        'SETTINGS!C11',  // savings target
        'MAIN!D9',       // remaining
        'MAIN!F9',       // spent
        'MAIN!H9',       // debt paid
        'MAIN!J9',       // saved
        'MAIN!N9',       // extra attack
        "'DEBT ENGINE'!D6:D14",  // balances
        "'DEBT ENGINE'!E6:E14",  // paid this month
        "'DEBT ENGINE'!F6:F14",  // remaining
      ];
      const json = await this.batchGet(RANGES);
      const vr = json.valueRanges;
      const v  = i => { const r = vr[i]?.values; return r?.[0]?.[0] ? parseFloat(r[0][0]) || r[0][0] : null; };
      const va = i => (vr[i]?.values || []).map(r => parseFloat(r[0]) || 0);

      const dbRem = va(10);
      const totalDebt = dbRem.reduce((a, b) => a + b, 0);

      const live = {
        ...DEMO_DATA,
        salary:    v(0)  || DEMO_DATA.salary,
        emergency: v(1)  || DEMO_DATA.emergency,
        savingsTarget: v(2) || 2000,
        spent:     v(4)  || DEMO_DATA.spent,
        debtPaid:  v(5)  || DEMO_DATA.debtPaid,
        savedAmt:  v(6)  || DEMO_DATA.savedAmt,
        extra:     v(7)  || DEMO_DATA.extra,
        totalDebt,
        debts: DEMO_DATA.debts.map((d, i) => ({
          ...d,
          rem:  dbRem[i]    ?? d.rem,
          paid: va(9)[i]   ?? d.paid,
          lim:  va(8)[i]   || d.lim,
        })),
      };
      live.netWorth = live.assets - live.totalDebt;

      saveData(live);
      State.syncStatus = 'success';
      UI.setSyncState('success');
      return { ok: true, data: live };

    } catch (err) {
      console.error('[Sheets sync]', err);
      State.syncStatus = 'error';
      UI.setSyncState('error');
      return { ok: false, error: err.message };
    }
  },

  // ── LOG EXPENSE TO SHEETS ──────────────────────────────
  async logExpense(expense) {
    if (!this.connected) return false;
    try {
      const d = new Date(expense.date);
      const dateStr = `${d.getDate()}/${d.getMonth()+1}/${d.getFullYear()}`;
      const catName = window.LANG === 'ar' ? expense.cat_ar : expense.cat_en;
      await this.appendRow([dateStr, 'Spending', expense.amt, catName, expense.name + ' — App']);
      return true;
    } catch (e) {
      console.error('[Sheets log]', e);
      return false;
    }
  },

  // ── EXPORT ────────────────────────────────────────────
  exportCSV() {
    const exp = State.isDemoMode ? DEMO_EXPENSES : State.expenses;
    const rows = [
      ['Date','Type','Amount','Category','Name','Month','Year'],
      ...exp.map(e => [e.date,'Spending',e.amt,e.cat_en||e.cat_ar,e.name,e.month,e.year])
    ];
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    downloadFile(csv, 'maliaty_expenses.csv', 'text/csv');
  },

  exportJSON() {
    const payload = {
      exportedAt: new Date().toISOString(),
      data: State.isDemoMode ? DEMO_DATA : (State.data || DEMO_DATA),
      expenses: State.isDemoMode ? DEMO_EXPENSES : State.expenses,
      history: State.isDemoMode ? DEMO_HISTORY : State.history,
    };
    downloadFile(JSON.stringify(payload, null, 2), 'maliaty_backup.json', 'application/json');
  },
};

function downloadFile(content, filename, type) {
  const blob = new Blob([content], { type });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
