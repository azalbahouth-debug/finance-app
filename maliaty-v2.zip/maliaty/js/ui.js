/* ═══════════════════════════════
   MALIATY — UI Renderer
═══════════════════════════════ */

// ── HELPERS ───────────────────────────────────────────────
const $ = id => document.getElementById(id);
const fmt = (n, short = false) => {
  if (n === null || n === undefined || isNaN(n)) return '--';
  const abs = Math.abs(n);
  if (short && abs >= 1000000) return (n / 1000000).toFixed(1) + (window.LANG === 'ar' ? 'م' : 'M');
  if (short && abs >= 1000)    return Math.round(abs).toLocaleString(window.LANG === 'ar' ? 'ar-SA' : 'en-US');
  return Math.round(abs).toLocaleString(window.LANG === 'ar' ? 'ar-SA' : 'en-US');
};
const pct   = (a, b) => b ? Math.min(100, Math.round(a / b * 100)) : 0;
const cur   = n => t('currency') + fmt(n, true);
const sign  = n => n < 0 ? '-' : '';

// ── THEME & LANG ──────────────────────────────────────────
const UI = {
  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    State.theme = theme;
    localStorage.setItem(KEYS.theme, theme);
  },
  applyLang(lang) {
    window.LANG = lang;
    State.lang  = lang;
    localStorage.setItem(KEYS.lang, lang);
    document.body.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);
    document.title = t('appName');
  },
  toggleTheme() {
    this.applyTheme(State.theme === 'light' ? 'dark' : 'light');
  },
  toggleLang() {
    this.applyLang(State.lang === 'ar' ? 'en' : 'ar');
    this.renderAll(false);
    this.renderNavMonthPill();
  },
  setSyncState(status) {
    const btn  = $('sync-btn');
    const bar  = $('sync-bar');
    if (!btn || !bar) return;
    btn.classList.remove('sync-spinning');
    bar.classList.remove('loading','done');
    if (status === 'syncing') { btn.classList.add('sync-spinning'); bar.classList.add('loading'); }
    if (status === 'success') { bar.classList.add('done'); }
    if (status === 'error')   { showToast('⚠️ ' + t('error')); }
  },

  // ── SCREENS ──────────────────────────────────────────
  showScreen(id) {
    document.querySelectorAll('.screen, .auth-screen').forEach(s => s.classList.remove('active'));
    const s = $(id);
    if (s) s.classList.add('active');
  },

  // ── TABS ──────────────────────────────────────────────
  switchTab(name, el) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    if (el) el.classList.add('active');
    const pg = $('page-' + name);
    if (pg) pg.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  // ── MONTH PILL ────────────────────────────────────────
  renderNavMonthPill() {
    const el = $('nav-month');
    if (!el) return;
    const mn = t(`month_${State.currentMonth}`);
    el.textContent = `${mn} ${State.currentYear}`;
  },

  // ── MASTER RENDER ────────────────────────────────────
  renderAll(sync = true) {
    const d = State.isDemoMode ? DEMO_DATA : (State.data || DEMO_DATA);
    const expenses = State.isDemoMode ? DEMO_EXPENSES : State.expenses;
    this.renderNavMonthPill();
    this.renderHome(d, expenses);
    this.renderDebts(d);
    this.renderSpending(expenses);
    this.renderBudget(d);
    this.renderSavings(d);
    this.renderHistory();
    this.renderProfile();
    this.renderTabs();
  },

  // ── TABS LABELS ──────────────────────────────────────
  renderTabs() {
    const tabs = [
      ['tab-home','tabHome'],['tab-debts','tabDebts'],['tab-spending','tabSpending'],
      ['tab-budget','tabBudget'],['tab-savings','tabSavings'],
      ['tab-history','tabHistory'],['tab-profile','tabProfile'],
    ];
    tabs.forEach(([id, key]) => { const el=$(id); if(el) el.textContent = t(key); });
  },

  // ── HOME ──────────────────────────────────────────────
  renderHome(d, expenses) {
    const monthExp = expenses.filter(e => e.month === State.currentMonth && e.year === State.currentYear);
    const spentLocal = monthExp.reduce((s, e) => s + e.amt, 0);
    const totalSpent = Math.max(d.spent, spentLocal);
    const remaining  = d.salary - totalSpent - d.debtPaid - d.savedAmt;
    const remColor   = remaining < 3000 ? 'var(--danger)' : remaining < 8000 ? 'var(--warning)' : 'var(--success)';

    setHTML('hero-remaining', `${t('currency')}<span style="color:${remColor}">${fmt(remaining, true)}</span>`);
    setText('hero-sub', `${t('heroSub')} ${t('currency')}${fmt(d.salary, true)}`);
    setHTML('chip-spent', `<div class="chip-val" style="color:var(--danger)">${cur(totalSpent)}</div><div class="chip-lbl">${t('chipSpent').replace('\n','<br>')}</div>`);
    setHTML('chip-debt',  `<div class="chip-val" style="color:var(--warning)">${cur(d.debtPaid)}</div><div class="chip-lbl">${t('chipDebt').replace('\n','<br>')}</div>`);
    setHTML('chip-saved', `<div class="chip-val" style="color:var(--success)">${cur(d.savedAmt)}</div><div class="chip-lbl">${t('chipSaved').replace('\n','<br>')}</div>`);

    // KPIs
    setText('kpi-ef-val',   cur(d.emergency));
    setText('kpi-ef-note',  `${pct(d.emergency, d.efTarget)}% ${t('kpiEmergencyNote')}`);
    setText('kpi-extra-val', cur(d.extra));
    setText('kpi-debt-val', cur(d.totalDebt));
    const nwEl = $('kpi-nw-val');
    if (nwEl) { nwEl.textContent = `${sign(d.netWorth)}${cur(Math.abs(d.netWorth))}`; nwEl.style.color = d.netWorth < 0 ? 'var(--danger)' : 'var(--success)'; }

    // Alerts
    const alerts = [];
    if (remaining < 3000)
      alerts.push({ type:'danger', icon:'🚨', title: t('alertLowBalance'), sub: t('alertLowBalanceSub', { rem: cur(remaining) }) });
    else if (remaining < 8000)
      alerts.push({ type:'warn',   icon:'⚠️', title: t('alertWatchBalance'), sub: t('alertWatchBalanceSub', { rem: cur(remaining) }) });
    else
      alerts.push({ type:'ok',     icon:'✅', title: t('alertHealthy'), sub: t('alertHealthySub', { rem: cur(remaining) }) });

    const ep = pct(d.emergency, d.efTarget);
    if (ep < 25)
      alerts.push({ type:'warn', icon:'🛡️', title: t('alertEFLow'), sub: t('alertEFLowSub', { pct: ep, target: cur(d.efTarget) }) });

    setHTML('alerts-container', alerts.map(a => `
      <div class="alert alert-${a.type} fade-in">
        <div class="alert-icon">${a.icon}</div>
        <div><div class="alert-title">${a.title}</div><div class="alert-sub">${a.sub}</div></div>
      </div>`).join(''));

    if (State.isDemoMode) {
      const demoBar = $('demo-bar');
      if (demoBar) { demoBar.style.display = 'block'; demoBar.textContent = `⚡ ${t('demo')} — ${t('demoNote')}`; }
    }
  },

  // ── DEBTS ─────────────────────────────────────────────
  renderDebts(d) {
    const render = (ids, type, label) => {
      const el = $(ids);
      if (!el) return;
      const items = d.debts.filter(x => x.type === type);
      if (!items.length) { el.innerHTML = `<div class="empty" style="padding:16px 0;font-size:12px">${label}</div>`; return; }
      el.innerHTML = items.map(debt => this.debtCardHTML(debt)).join('');
    };
    render('cc-cards',   'cc',   '');
    render('loan-cards', 'loan', '');
    render('mort-cards', 'mort', '');
    render('bnpl-cards', 'bnpl', '');
  },

  debtCardHTML(d) {
    const p = pct(d.paid, d.lim);
    const colors = { cc:'var(--brand)', loan:'var(--danger)', mort:'var(--success)', bnpl:'var(--warning)' };
    const badges = { cc:'badge-cc', loan:'badge-loan', mort:'badge-mort', bnpl:'badge-bnpl' };
    const badgeTexts = { cc: t('badgeCC'), loan: t('badgeLoan'), mort: t('badgeMort'), bnpl: t('badgeBNPL') };
    const c = colors[d.type] || 'var(--brand)';
    const nameDisplay = window.LANG === 'en' && d.name.includes('/') ? d.name.split('/')[1].trim() : d.name.split('/')[0].trim();
    return `
    <div class="debt-card">
      <div class="debt-top">
        <div class="debt-name">${nameDisplay}</div>
        <div class="badge ${badges[d.type]}">${badgeTexts[d.type]}</div>
      </div>
      <div class="debt-num">${d.num}</div>
      <div class="debt-amounts">
        <div>
          <div class="debt-rem-lbl">${t('labelRemaining')}</div>
          <div class="debt-rem" style="color:${c}">${t('currency')}${fmt(d.rem)}</div>
        </div>
        <div class="debt-paid-side">
          <div class="debt-paid-lbl">${t('labelPaidMonth')}</div>
          <div class="debt-paid-val">${t('currency')}${fmt(d.paid)}</div>
        </div>
      </div>
      <div class="progress-track">
        <div class="progress-fill" style="width:${p}%;background:${c}"></div>
      </div>
    </div>`;
  },

  // ── SPENDING ──────────────────────────────────────────
  renderSpending(expenses, filter = '') {
    const el = $('spending-list');
    if (!el) return;
    let list = expenses.filter(e => e.month === State.currentMonth && e.year === State.currentYear);
    if (filter) list = list.filter(e =>
      e.name.toLowerCase().includes(filter) ||
      (e.cat_ar||'').includes(filter) ||
      (e.cat_en||'').toLowerCase().includes(filter)
    );
    if (!list.length) {
      el.innerHTML = `<div class="empty"><div class="empty-icon">📭</div><div class="empty-text">${t('spendEmpty')}<br><small>${t('spendEmptySub')}</small></div></div>`;
      return;
    }
    el.innerHTML = list.map(e => this.spendItemHTML(e)).join('');
  },

  spendItemHTML(e) {
    const cat = window.LANG === 'ar' ? e.cat_ar : e.cat_en;
    const dateStr = new Date(e.date).toLocaleDateString(window.LANG === 'ar' ? 'ar-SA' : 'en-US', { day:'numeric', month:'short' });
    return `
    <div class="spend-item" data-id="${e.id}">
      <div class="spend-emoji" style="background:${e.bg || 'var(--muted)'}">${e.emoji || '💰'}</div>
      <div class="spend-info">
        <div class="spend-name">${e.name}</div>
        <div class="spend-meta">${cat} · ${dateStr}</div>
      </div>
      <div class="spend-right">
        <div class="spend-amt" style="color:var(--danger)">-${t('currency')}${fmt(e.amt)}</div>
        <div class="spend-cat" onclick="Modals.openSpendAction('${e.id}')" style="color:var(--brand);cursor:pointer;margin-top:4px">•••</div>
      </div>
    </div>`;
  },

  // ── BUDGET ────────────────────────────────────────────
  renderBudget(d) {
    const el = $('budget-list');
    if (!el) return;
    el.innerHTML = d.budgets.map(b => {
      const p     = pct(b.actual, b.budget);
      const over  = b.actual > b.budget;
      const bc    = over ? 'var(--danger)' : p > 80 ? 'var(--warning)' : 'var(--success)';
      const cat   = window.LANG === 'ar' ? b.cat_ar : b.cat_en;
      return `
      <div class="budget-item">
        <div class="budget-row">
          <div class="budget-name" style="${over ? 'color:var(--danger)' : ''}">${b.emoji} ${cat}</div>
          <div class="budget-nums" style="${over ? 'color:var(--danger)' : ''}"><strong>${t('currency')}${fmt(b.actual)}</strong> / ${t('currency')}${fmt(b.budget)}</div>
        </div>
        <div class="budget-bar-track">
          <div class="budget-bar-fill" style="width:${p}%;background:${bc}"></div>
        </div>
      </div>`;
    }).join('');
  },

  // ── SAVINGS ───────────────────────────────────────────
  renderSavings(d) {
    const p       = pct(d.emergency, d.efTarget);
    const gap     = Math.max(0, d.efTarget - d.emergency);
    const months  = Math.ceil(gap / 2000);
    const faster  = Math.ceil(gap / 2806);

    setHTML('savings-ef', `
      <div class="savings-card">
        <div class="savings-head">
          <div><div class="savings-title">🛡️ ${t('efTitle')}</div><div class="savings-sub">${t('efSub')}</div></div>
          <div class="savings-pct">${p}%</div>
        </div>
        <div class="savings-bar-track"><div class="savings-bar-fill" style="width:${p}%"></div></div>
        <div class="savings-stats">
          <span>${t('efCurrent')}: <strong>${t('currency')}${fmt(d.emergency)}</strong></span>
          <span>${t('efTarget')}: <strong>${t('currency')}${fmt(d.efTarget)}</strong></span>
        </div>
      </div>`);

    setHTML('savings-plan', `
      <div class="savings-card">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
          <div style="text-align:center;background:var(--muted);border-radius:var(--r-md);padding:14px;border:1px solid var(--border)">
            <div style="font-size:28px;font-weight:700;color:var(--warning);margin-bottom:4px">${months}</div>
            <div style="font-size:11px;color:var(--t2)">${t('planMonths')}</div>
          </div>
          <div style="text-align:center;background:var(--muted);border-radius:var(--r-md);padding:14px;border:1px solid var(--border)">
            <div style="font-size:22px;font-weight:700;color:var(--success);margin-bottom:4px">${t('currency')}2,000</div>
            <div style="font-size:11px;color:var(--t2)">${t('planMonthly')}</div>
          </div>
        </div>
        <div style="padding:14px;background:var(--brand-soft);border-radius:var(--r-md);border:1px solid rgba(37,99,235,0.15)">
          <div style="font-size:13px;font-weight:700;color:var(--brand);margin-bottom:6px">💡 ${t('planFasterTitle')}</div>
          <div style="font-size:12px;color:var(--t2);line-height:1.7">
            Tamara Alsuwaid (${t('currency')}377) + Tabby Al Rajhi (${t('currency')}429) →
            <strong style="color:var(--t1)">${faster} ${t('planMonths')}</strong>
          </div>
        </div>
      </div>`);
  },

  // ── HISTORY ───────────────────────────────────────────
  renderHistory() {
    const el = $('history-list');
    if (!el) return;
    const hist = State.isDemoMode ? DEMO_HISTORY : State.history;
    if (!hist.length) {
      el.innerHTML = `<div class="empty"><div class="empty-icon">📅</div><div class="empty-text">${t('historyEmpty')}<br><small>${t('historyEmptySub')}</small></div></div>`;
      return;
    }
    el.innerHTML = hist.map(h => {
      const name = window.LANG === 'ar' ? h.monthName_ar : h.monthName_en;
      const rem  = h.remaining || (h.salary - h.spent - h.debtPaid - h.saved);
      const rc   = rem < 0 ? 'var(--danger)' : 'var(--success)';
      return `
      <div class="history-month" onclick="showMonthDetail('${h.key}')">
        <div>
          <div class="history-month-name">${name}</div>
          <div class="history-month-sub">${t('currency')}${fmt(h.spent)} ${window.LANG==='ar'?'مصروف':'spent'} · ${t('currency')}${fmt(h.saved)} ${window.LANG==='ar'?'مدخر':'saved'}</div>
        </div>
        <div class="history-month-right">
          <div class="history-month-rem" style="color:${rc}">${t('currency')}${fmt(rem)}</div>
          <div class="history-month-arrow" style="color:var(--t3)">${window.LANG==='ar'?'←':'→'}</div>
        </div>
      </div>`;
    }).join('');
  },

  // ── PROFILE ───────────────────────────────────────────
  renderProfile() {
    const el = $('profile-content');
    if (!el) return;
    const user   = State.session || {};
    const initials = (user.identifier || 'U')[0].toUpperCase();
    const themeLabel = State.theme === 'dark' ? (window.LANG==='ar'?'داكن':'Dark') : (window.LANG==='ar'?'فاتح':'Light');
    el.innerHTML = `
      <div class="profile-card">
        <div class="profile-avatar">${initials}</div>
        <div class="profile-name">${user.identifier || t('demo')}</div>
        <div class="profile-sub">${State.isDemoMode ? t('demoNote') : t('appTagline')}</div>
      </div>

      <div class="setting-row" onclick="Modals.openSetupSheets()">
        <div class="setting-left">
          <div class="setting-icon">📊</div>
          <div><div class="setting-label">${t('settingSheets')}</div><div class="setting-sub">${Sheets.connected ? t('setupConnected') : t('settingSheetsSub')}</div></div>
        </div>
        <div class="setting-arrow">›</div>
      </div>

      <div class="setting-row" onclick="UI.toggleLang()">
        <div class="setting-left">
          <div class="setting-icon">🌐</div>
          <div><div class="setting-label">${t('settingLanguage')}</div><div class="setting-sub">${State.lang === 'ar' ? 'العربية' : 'English'}</div></div>
        </div>
        <div class="toggle ${State.lang === 'en' ? 'on' : ''}"></div>
      </div>

      <div class="setting-row" onclick="UI.toggleTheme(); UI.renderProfile()">
        <div class="setting-left">
          <div class="setting-icon">☀️</div>
          <div><div class="setting-label">${t('settingTheme')}</div><div class="setting-sub">${themeLabel}</div></div>
        </div>
        <div class="toggle ${State.theme === 'dark' ? 'on' : ''}"></div>
      </div>

      <div class="setting-row" onclick="Sheets.exportCSV()">
        <div class="setting-left">
          <div class="setting-icon">📤</div>
          <div><div class="setting-label">${t('settingExport')}</div><div class="setting-sub">${t('settingExportSub')}</div></div>
        </div>
        <div class="setting-arrow">›</div>
      </div>

      <div class="setting-row" onclick="Auth.logout()" style="border-color:var(--danger-soft)">
        <div class="setting-left">
          <div class="setting-icon">🚪</div>
          <div><div class="setting-label" style="color:var(--danger)">${t('settingLogout')}</div><div class="setting-sub">${t('settingLogoutSub')}</div></div>
        </div>
        <div class="setting-arrow" style="color:var(--danger)">›</div>
      </div>`;
  },
};

// ── DOM HELPERS ───────────────────────────────────────────
function setHTML(id, html) { const el=$(id); if(el) el.innerHTML = html; }
function setText(id, text) { const el=$(id); if(el) el.textContent = text; }

// ── TOAST ─────────────────────────────────────────────────
function showToast(msg, dur = 2800) {
  const el = $('toast');
  if (!el) return;
  el.textContent = msg; el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), dur);
}

// ── MONTH DETAIL (simple) ────────────────────────────────
function showMonthDetail(key) {
  const hist = State.isDemoMode ? DEMO_HISTORY : State.history;
  const h = hist.find(x => x.key === key);
  if (!h) return;
  const name = window.LANG === 'ar' ? h.monthName_ar : h.monthName_en;
  showToast(`${name}: ${t('currency')}${fmt(h.spent)} ${window.LANG==='ar'?'مصروف':'spent'}`);
}
