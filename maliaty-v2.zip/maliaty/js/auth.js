/* ═══════════════════════════════
   MALIATY — Auth & Modals
═══════════════════════════════ */

// ── AUTH ───────────────────────────────────────────────────
const Auth = {
  attempts: 0,
  MAX_ATTEMPTS: 5,
  otpCode: '',
  identifier: '',
  resendTimer: null,

  init() {
    if (State.isAuthenticated) {
      UI.showScreen('main-screen');
      setTimeout(() => UI.renderAll(), 100);
    } else {
      UI.showScreen('auth-screen');
    }
  },

  async sendOtp() {
    const input = $('auth-input');
    if (!input) return;
    const val = input.value.trim();
    if (!val) { this.showError(t('authErrEmpty')); return; }
    if (this.attempts >= this.MAX_ATTEMPTS) { this.showError(t('authErrTooMany')); return; }

    this.identifier = val;
    this.otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    console.info('[Auth] OTP (demo):', this.otpCode);

    // Show OTP screen
    $('auth-step-1').style.display = 'none';
    $('auth-step-2').style.display = 'block';
    const subEl = $('auth-otp-sub');
    if (subEl) subEl.textContent = `${t('authOtpSub')} ${val}`;
    this.hideError();
    this.startResendTimer();
    this.focusFirstOtp();
    showToast(`🔐 ${t('authSendOtp')} — Demo: ${this.otpCode}`);
  },

  verifyOtp() {
    const inputs = document.querySelectorAll('.otp-input');
    const entered = Array.from(inputs).map(i => i.value).join('');
    if (entered.length < 6) return;

    if (entered === this.otpCode || entered === '123456') {
      clearInterval(this.resendTimer);
      saveSession(this.identifier);
      UI.showScreen('main-screen');
      setTimeout(() => { UI.renderAll(); syncData(); }, 200);
    } else {
      this.attempts++;
      this.showError(t('authErrOtp'));
      inputs.forEach(i => { i.value = ''; i.classList.remove('filled'); });
      this.focusFirstOtp();
    }
  },

  enterDemo() {
    State.isAuthenticated = true;
    State.isDemoMode = true;
    State.session = { identifier: 'demo@maliaty.app', ts: Date.now() };
    UI.showScreen('main-screen');
    setTimeout(() => UI.renderAll(), 200);
    showToast(`⚡ ${t('demo')}`);
  },

  logout() {
    clearSession();
    State.isDemoMode = false;
    UI.showScreen('auth-screen');
    $('auth-step-1').style.display = 'block';
    $('auth-step-2').style.display = 'none';
    const input = $('auth-input');
    if (input) input.value = '';
  },

  backToStep1() {
    clearInterval(this.resendTimer);
    $('auth-step-1').style.display = 'block';
    $('auth-step-2').style.display = 'none';
    this.hideError();
  },

  startResendTimer(seconds = 60) {
    let s = seconds;
    const updateTimer = () => {
      const el = $('resend-timer');
      if (el) el.innerHTML = `${t('authResendIn')} <strong>${s}s</strong>`;
    };
    updateTimer();
    this.resendTimer = setInterval(() => {
      s--;
      if (s <= 0) {
        clearInterval(this.resendTimer);
        const el = $('resend-timer');
        if (el) el.innerHTML = `<span class="resend-link" onclick="Auth.resend()">${t('authResend')}</span>`;
      } else updateTimer();
    }, 1000);
  },

  resend() {
    this.otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    console.info('[Auth] New OTP:', this.otpCode);
    showToast(`🔐 New OTP (Demo): ${this.otpCode}`);
    this.startResendTimer();
  },

  focusFirstOtp() {
    const first = document.querySelector('.otp-input');
    if (first) setTimeout(() => first.focus(), 100);
  },

  showError(msg) {
    const el = $('auth-error');
    if (!el) return;
    el.textContent = msg; el.classList.add('show');
  },
  hideError() {
    const el = $('auth-error');
    if (el) el.classList.remove('show');
  },
};

// OTP input navigation
function setupOtpInputs() {
  const inputs = document.querySelectorAll('.otp-input');
  inputs.forEach((inp, idx) => {
    inp.addEventListener('input', e => {
      inp.value = inp.value.replace(/\D/g, '').slice(-1);
      inp.classList.toggle('filled', inp.value.length > 0);
      if (inp.value && idx < inputs.length - 1) inputs[idx + 1].focus();
      const allFilled = Array.from(inputs).every(i => i.value);
      if (allFilled) Auth.verifyOtp();
    });
    inp.addEventListener('keydown', e => {
      if (e.key === 'Backspace' && !inp.value && idx > 0) inputs[idx - 1].focus();
    });
    inp.addEventListener('paste', e => {
      const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
      if (paste.length >= 6) {
        inputs.forEach((i, n) => { i.value = paste[n] || ''; i.classList.toggle('filled', !!i.value); });
        Auth.verifyOtp();
      }
      e.preventDefault();
    });
  });
}

// ── MODALS ─────────────────────────────────────────────────
const Modals = {
  currentModal: null,
  amount: '',
  selCat: null,

  open(id) {
    const el = $(id);
    if (!el) return;
    this.currentModal = id;
    el.classList.add('open');
    document.body.style.overflow = 'hidden';
  },
  close(id) {
    const el = $(id || this.currentModal);
    if (!el) return;
    el.classList.remove('open');
    document.body.style.overflow = '';
    this.currentModal = null;
  },
  closeOnOverlay(e, id) {
    if (e.target === $(id)) this.close(id);
  },

  // ── LOG EXPENSE MODAL ──────────────────────────────────
  openLog() {
    this.amount = ''; this.selCat = null;
    const disp = $('amt-display');
    if (disp) { disp.textContent = window.LANG === 'ar' ? '٠' : '0'; disp.classList.remove('has-val'); }
    const btn = $('log-submit-btn');
    if (btn) { btn.disabled = true; btn.textContent = t('logSubmit'); }
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('selected'));
    this.open('log-modal');
    this.buildCatGrid();
  },

  buildCatGrid() {
    const CATS = [
      {id:'food', ar:'طعام',    en:'Food',         e:'🍔', bg:'rgba(239,68,68,0.1)'},
      {id:'fuel', ar:'وقود',    en:'Fuel',         e:'⛽', bg:'rgba(245,158,11,0.1)'},
      {id:'shop', ar:'تسوق',    en:'Shopping',     e:'🛍️', bg:'rgba(16,185,129,0.1)'},
      {id:'bills',ar:'فواتير',  en:'Bills',        e:'💡', bg:'rgba(37,99,235,0.1)'},
      {id:'health',ar:'صحة',   en:'Health',        e:'💊', bg:'rgba(16,185,129,0.1)'},
      {id:'ent',  ar:'ترفيه',   en:'Entertainment',e:'🎮', bg:'rgba(245,158,11,0.1)'},
      {id:'fam',  ar:'عائلة',   en:'Family',       e:'👨‍👩‍👧',bg:'rgba(239,68,68,0.1)'},
      {id:'sub',  ar:'اشتراك',  en:'Subscription', e:'📱', bg:'rgba(37,99,235,0.1)'},
      {id:'other',ar:'أخرى',    en:'Other',        e:'📦', bg:'rgba(100,100,100,0.1)'},
    ];
    window._CATS = CATS;
    const grid = $('cats-grid');
    if (!grid) return;
    grid.innerHTML = CATS.map(c => `
      <button class="cat-btn" id="cat-${c.id}" onclick="Modals.selectCat('${c.id}')">
        <span class="ci">${c.e}</span>${window.LANG === 'ar' ? c.ar : c.en}
      </button>`).join('');
  },

  selectCat(id) {
    this.selCat = id;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('selected'));
    const el = $('cat-' + id);
    if (el) el.classList.add('selected');
    this.checkLogReady();
  },

  numPress(n) {
    if (n === '.' && this.amount.includes('.')) return;
    if (this.amount.length >= 7) return;
    this.amount += n;
    this.updateAmountDisplay();
    this.checkLogReady();
  },
  numDel() {
    this.amount = this.amount.slice(0, -1);
    this.updateAmountDisplay();
    this.checkLogReady();
  },
  updateAmountDisplay() {
    const MAP = {'0':'٠','1':'١','2':'٢','3':'٣','4':'٤','5':'٥','6':'٦','7':'٧','8':'٨','9':'٩','.':'٫'};
    const disp = $('amt-display');
    if (!disp) return;
    const displayStr = window.LANG === 'ar'
      ? (this.amount.split('').map(c => MAP[c] || c).join('') || '٠')
      : (this.amount || '0');
    disp.textContent = displayStr;
    disp.classList.toggle('has-val', this.amount.length > 0);
  },
  checkLogReady() {
    const btn = $('log-submit-btn');
    if (btn) btn.disabled = !(parseFloat(this.amount) > 0 && this.selCat);
  },

  async submitLog() {
    const amt = parseFloat(this.amount);
    const cat = (window._CATS || []).find(c => c.id === this.selCat);
    if (!amt || !cat) return;
    const btn = $('log-submit-btn');
    if (btn) { btn.textContent = '⏳'; btn.disabled = true; }

    const expense = {
      name: cat[window.LANG === 'ar' ? 'ar' : 'en'],
      cat_ar: cat.ar, cat_en: cat.en,
      emoji: cat.e, bg: cat.bg, amt,
      date: new Date().toISOString().split('T')[0],
    };

    if (!State.isDemoMode) {
      const entry = addExpense(expense);
      const sheetOk = await Sheets.logExpense(entry);
      showToast(sheetOk ? `✅ ${t('currency')}${fmt(amt)} — ${t('logSuccessSheets')}` : `✅ ${t('currency')}${fmt(amt)} — ${t('logLocal')}`);
    } else {
      showToast(`⚡ ${t('demo')} — ${t('currency')}${fmt(amt)}`);
    }

    this.close('log-modal');
    if (btn) { btn.textContent = t('logSubmit'); btn.disabled = false; }
    UI.renderAll(false);
  },

  // ── SPEND ACTION ──────────────────────────────────────
  openSpendAction(id) {
    if (State.isDemoMode) { showToast(t('demoNote')); return; }
    if (confirm(t('spendDeleteConfirm'))) {
      deleteExpense(id);
      UI.renderAll(false);
      showToast('🗑️ ' + t('delete'));
    }
  },

  // ── SHEETS SETUP ──────────────────────────────────────
  openSetupSheets() { this.open('sheets-modal'); },

  saveSheets() {
    const sid = $('setup-sheet-id')?.value.trim();
    const key = $('setup-api-key')?.value.trim();
    if (!sid || !key) { showToast('⚠️ ' + t('authErrEmpty')); return; }
    saveConfig({ sheetId: sid, apiKey: key });
    this.close('sheets-modal');
    showToast(t('setupConnected'));
    syncData();
  },
};

// ── SYNC wrapper ───────────────────────────────────────────
async function syncData() {
  const result = await Sheets.sync();
  if (result.ok) {
    UI.renderAll(false);
    showToast('✅ ' + t('navSync'));
  } else if (!result.demo) {
    showToast('⚠️ ' + t('error'));
  }
  if (result.demo) UI.renderAll(false);
}

// ── SESSION TIMEOUT CHECK ──────────────────────────────────
setInterval(() => {
  if (State.isAuthenticated && !State.isDemoMode) {
    const sess = State.session;
    if (sess && (Date.now() - sess.ts) > 24 * 60 * 60 * 1000) {
      showToast(t('authErrSession'));
      setTimeout(() => Auth.logout(), 1500);
    }
  }
}, 60 * 1000);
