/* ═══════════════════════════════
   MALIATY — State & Data Store
═══════════════════════════════ */

// ── KEYS ──────────────────────────────────────────────────
const KEYS = {
  theme:    'mal_theme',
  lang:     'mal_lang',
  session:  'mal_session',
  config:   'mal_config',
  data:     'mal_data',
  history:  'mal_history',
  expenses: 'mal_expenses',
};

// ── STATE ─────────────────────────────────────────────────
const State = {
  theme: 'light',
  lang: 'ar',
  isAuthenticated: false,
  isDemoMode: false,
  config: { sheetId: '', apiKey: '' },
  currentMonth: new Date().getMonth(),
  currentYear:  new Date().getFullYear(),
  data: null,
  history: [],
  expenses: [],
  syncStatus: 'idle', // idle | syncing | success | error
};

// ── LOAD FROM STORAGE ─────────────────────────────────────
function loadState() {
  State.theme  = localStorage.getItem(KEYS.theme) || 'light';
  State.lang   = localStorage.getItem(KEYS.lang)  || 'ar';
  const cfg    = safeGet(KEYS.config);
  if (cfg) State.config = cfg;
  const hist   = safeGet(KEYS.history);
  if (hist) State.history = hist;
  const exp    = safeGet(KEYS.expenses);
  if (exp) State.expenses = exp;
  const data   = safeGet(KEYS.data);
  if (data) State.data = data;

  // Check session (24h timeout)
  const sess = safeGet(KEYS.session);
  if (sess && sess.ts && (Date.now() - sess.ts) < 24 * 60 * 60 * 1000) {
    State.isAuthenticated = true;
    State.session = sess;
  }
}

function safeGet(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function safeSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

function saveSession(identifier) {
  const sess = { identifier, ts: Date.now() };
  State.isAuthenticated = true;
  State.session = sess;
  safeSet(KEYS.session, sess);
}

function clearSession() {
  State.isAuthenticated = false;
  State.isDemoMode = false;
  State.session = null;
  localStorage.removeItem(KEYS.session);
}

function saveConfig(cfg) {
  State.config = cfg;
  safeSet(KEYS.config, cfg);
}

function saveData(data) {
  State.data = data;
  safeSet(KEYS.data, data);
}

// ── EXPENSE MANAGEMENT ────────────────────────────────────
function addExpense(exp) {
  const entry = {
    id: Date.now().toString(),
    ...exp,
    createdAt: new Date().toISOString(),
    month: State.currentMonth,
    year:  State.currentYear,
  };
  State.expenses.unshift(entry);
  safeSet(KEYS.expenses, State.expenses);
  return entry;
}

function deleteExpense(id) {
  State.expenses = State.expenses.filter(e => e.id !== id);
  safeSet(KEYS.expenses, State.expenses);
}

function editExpense(id, updates) {
  State.expenses = State.expenses.map(e => e.id === id ? { ...e, ...updates } : e);
  safeSet(KEYS.expenses, State.expenses);
}

function getExpensesByMonth(month, year) {
  return State.expenses.filter(e => e.month === month && e.year === year);
}

// ── HISTORY MANAGEMENT ────────────────────────────────────
function archiveMonth(monthData) {
  const key = `${monthData.year}-${monthData.month}`;
  const existing = State.history.findIndex(h => h.key === key);
  if (existing >= 0) State.history[existing] = { key, ...monthData };
  else State.history.unshift({ key, ...monthData });
  safeSet(KEYS.history, State.history);
}

function getMonthHistory(month, year) {
  return State.history.find(h => h.key === `${year}-${month}`) || null;
}

// ── DEMO DATA ─────────────────────────────────────────────
const DEMO_DATA = {
  salary: 40978, spent: 8720, debtPaid: 18569.08,
  savedAmt: 2000, emergency: 15000, efTarget: 165654,
  extra: 1688.92, totalDebt: 3183660.31, netWorth: -3127682,
  assets: 1895000,
  debts: [
    { id:'d1', name:'رياض Signature / Riyad Signature', num:'****8935', type:'cc', rem:13998.82, lim:14000, paid:0 },
    { id:'d2', name:'الراجحي Infinite / AlRajhi Infinite', num:'****1264', type:'cc', rem:29896.29, lim:30000, paid:103.71 },
    { id:'d3', name:'تمويل شخصي ١ / Loan 1', num:'769940*', type:'loan', rem:478729.02, lim:487729.02, paid:9769.98 },
    { id:'d4', name:'تمويل شخصي ٢ / Loan 2', num:'769940*', type:'loan', rem:42521.05, lim:42521.05, paid:2237.95 },
    { id:'d5', name:'التمويل العقاري / Mortgage', num:'769940*', type:'mort', rem:1698743.93, lim:2600331.08, paid:6561.15 },
    { id:'d6', name:'Tabby — Almanea', num:'Tabby', type:'bnpl', rem:2885, lim:2885, paid:0 },
    { id:'d7', name:'Tabby — Al Rajhi Takaful', num:'Tabby', type:'bnpl', rem:429, lim:429, paid:0 },
    { id:'d8', name:'Tamara — Amazon', num:'Tamara', type:'bnpl', rem:1385, lim:1385, paid:0 },
    { id:'d9', name:'Tamara — Alsuwaid', num:'Tamara', type:'bnpl', rem:377, lim:377, paid:0 },
  ],
  budgets: [
    { cat_ar:'فواتير',    cat_en:'Bills',         emoji:'💡', budget:1500, actual:820  },
    { cat_ar:'طعام وقهوة',cat_en:'Food & Coffee', emoji:'🍔', budget:2000, actual:1680 },
    { cat_ar:'وقود',      cat_en:'Fuel',          emoji:'⛽', budget:800,  actual:500  },
    { cat_ar:'تسوق',      cat_en:'Shopping',      emoji:'🛍️', budget:1500, actual:980  },
    { cat_ar:'ترفيه',     cat_en:'Entertainment', emoji:'🎮', budget:500,  actual:185  },
    { cat_ar:'اشتراكات',  cat_en:'Subscriptions', emoji:'📱', budget:200,  actual:140  },
    { cat_ar:'صحة',       cat_en:'Health',        emoji:'💪', budget:400,  actual:0    },
    { cat_ar:'عائلة',     cat_en:'Family',        emoji:'👨‍👩‍👧', budget:1000, actual:350  },
    { cat_ar:'سفر',       cat_en:'Travel',        emoji:'✈️', budget:500,  actual:0    },
    { cat_ar:'أخرى',      cat_en:'Other',         emoji:'📦', budget:500,  actual:65   },
  ],
};

const DEMO_EXPENSES = [
  { id:'e1', name:'HungerStation', cat_ar:'طعام', cat_en:'Food', emoji:'🍔', bg:'rgba(239,68,68,0.1)', amt:185, date:'2026-05-13', month:4, year:2026 },
  { id:'e2', name:'Starbucks',     cat_ar:'قهوة', cat_en:'Coffee', emoji:'☕', bg:'rgba(239,68,68,0.1)', amt:42,  date:'2026-05-13', month:4, year:2026 },
  { id:'e3', name:'Shell Station', cat_ar:'وقود', cat_en:'Fuel',  emoji:'⛽', bg:'rgba(245,158,11,0.1)', amt:250, date:'2026-05-12', month:4, year:2026 },
  { id:'e4', name:'Apple iCloud+', cat_ar:'اشتراكات', cat_en:'Subscriptions', emoji:'☁️', bg:'rgba(37,99,235,0.1)', amt:45, date:'2026-05-01', month:4, year:2026 },
  { id:'e5', name:'Noon',          cat_ar:'تسوق', cat_en:'Shopping', emoji:'🛍️', bg:'rgba(16,185,129,0.1)', amt:320, date:'2026-05-03', month:4, year:2026 },
  { id:'e6', name:'Lulu Hypermarket', cat_ar:'سوبرماركت', cat_en:'Supermarket', emoji:'🛒', bg:'rgba(239,68,68,0.1)', amt:480, date:'2026-05-05', month:4, year:2026 },
];

const DEMO_HISTORY = [
  { key:'2026-3', year:2026, month:3, monthName_ar:'أبريل ٢٠٢٦', monthName_en:'April 2026', salary:40978, spent:9200, debtPaid:18569.08, saved:2000, remaining:11208.92, totalDebt:3202230, note:'Baseline' },
  { key:'2026-2', year:2026, month:2, monthName_ar:'مارس ٢٠٢٦', monthName_en:'March 2026', salary:40978, spent:7800, debtPaid:18569.08, saved:2000, remaining:12608.92, totalDebt:3220800, note:'' },
];
