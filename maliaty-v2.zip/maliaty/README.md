# ماليتي — Maliaty Finance App v2

## 📁 Project Structure

```
maliaty/
├── index.html          ← Main app entry point
├── css/
│   ├── tokens.css      ← Design tokens (colors, spacing, theme)
│   └── main.css        ← All styles (light + dark mode)
├── js/
│   ├── i18n.js         ← Arabic + English translations
│   ├── state.js        ← Data store, demo data, persistence
│   ├── sheets.js       ← Google Sheets API integration
│   ├── ui.js           ← All UI rendering
│   └── auth.js         ← OTP auth, session, modals
└── pwa/
    ├── manifest.json   ← PWA manifest
    ├── sw.js           ← Service worker (offline support)
    ├── icon-192.png    ← App icon (add your own)
    └── icon-512.png    ← App icon (add your own)
```

---

## 🚀 Deployment (GitHub Pages — Free)

1. Upload all files to your GitHub repository keeping the folder structure
2. Go to Settings → Pages → Deploy from `main` branch, root `/`
3. Visit: `https://[username].github.io/[repo-name]/`

---

## 📱 iPhone Home Screen (PWA)

1. Open the URL in **Safari** (not Chrome)
2. Tap the **Share** button (box with arrow)
3. Tap **Add to Home Screen**
4. Tap **Add**

The app will open fullscreen like a native app.

---

## 🔗 Google Sheets Setup

### Step 1 — Enable Google Sheets API
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project → Enable **Google Sheets API**
3. Go to **Credentials** → **Create Credentials** → **API Key**
4. Restrict key to Google Sheets API only (recommended)

### Step 2 — Get Sheet ID
Your Sheet URL looks like:
```
https://docs.google.com/spreadsheets/d/[SHEET_ID]/edit
```
Copy the `[SHEET_ID]` part.

### Step 3 — Connect in App
1. Open the app → Profile tab → Google Sheets
2. Enter Sheet ID and API Key
3. Tap **ربط / Connect**

---

## 🔐 Authentication

The app uses OTP-based authentication:
- User enters mobile/email → receives 6-digit OTP
- **In this demo version**, OTP is shown in a toast notification
- For production: integrate with an SMS provider (Twilio, Unifonic, etc.)
- Sessions expire after **24 hours**
- Failed attempts are tracked (max 5 before lockout)
- **Demo mode** is available without login (tap "تجربة بدون تسجيل")

---

## 💾 Data Persistence

| Data Type | Storage | Persistence |
|---|---|---|
| Expenses | localStorage | Permanent (until deleted) |
| History | localStorage | Permanent |
| Config | localStorage | Permanent |
| Session | localStorage | 24 hours |
| Live data | Google Sheets (primary) | Permanent in Sheets |

---

## 🌐 Language & Theme

- **Default**: Arabic (RTL), Light Mode
- Switch language: Profile → Language OR auth screen
- Switch theme: Nav bar ☀️ button OR Profile → Theme
- All text translated: buttons, tabs, alerts, modals

---

## 📊 What Gets Synced from Sheets

| Sheets Cell | Data |
|---|---|
| SETTINGS!C9 | Monthly salary |
| SETTINGS!C13 | Emergency fund balance |
| MAIN!D9 | Remaining cash |
| MAIN!F9 | Total spent |
| MAIN!H9 | Debt paid |
| MAIN!J9 | Amount saved |
| DEBT ENGINE!F6:F14 | All debt remaining balances |

---

## 📤 Export Options

- **CSV**: Profile → Export → downloads `maliaty_expenses.csv`
- **JSON Backup**: Profile → Export (use Sheets.exportJSON() in console)

---

## 🔧 Customizing

### Change Salary / Budgets
Edit in Google Sheets → SETTINGS sheet → all values update automatically.

### Add More Debt Accounts
Add rows to DEBT ENGINE sheet. Update `DEMO_DATA.debts` array in `js/state.js`.

### Change Currency
Search `t('currency')` in `js/i18n.js` — change `﷼` and `SAR` values.

---

## 🛡️ Security Notes

- API Key is stored in localStorage (client-side only)
- For production, route Sheets API calls through a backend proxy
- OTP verification should use a real SMS provider in production
- Session tokens should be JWT-signed on a real backend

---

## 📋 Checklist Before Launch

- [ ] Replace demo OTP with real SMS provider
- [ ] Add real app icons (192x192 and 512x512 PNG)
- [ ] Set up Google Sheets API with key restrictions
- [ ] Test on iPhone Safari (PWA installation)
- [ ] Test offline mode (disconnect WiFi after first load)
- [ ] Update Sheet ID and API Key in the app
